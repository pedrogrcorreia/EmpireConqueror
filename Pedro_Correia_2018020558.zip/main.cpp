//
// Created by Pedro Correia.
//

#include "Interface.h"
using namespace std;

int main(){
    Interface i;
    i.start();
    return 0;
}
